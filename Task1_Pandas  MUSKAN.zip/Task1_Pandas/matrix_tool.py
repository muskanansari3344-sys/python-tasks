import numpy as np

print("=== MATRIX OPERATIONS TOOL ===")

# Matrix A
rowsA = int(input("Matrix A - rows: "))
colsA = int(input("Matrix A - columns: "))

print("Matrix A ke elements row-wise daalo:")
A = []
for i in range(rowsA):
    A.append(list(map(int, input().split())))
A = np.array(A)

# Matrix B
rowsB = int(input("Matrix B - rows: "))
colsB = int(input("Matrix B - columns: "))

print("Matrix B ke elements row-wise daalo:")
B = []
for i in range(rowsB):
    B.append(list(map(int, input().split())))
B = np.array(B)

print("\nMatrix A:\n", A)
print("\nMatrix B:\n", B)

print("""
Choose Operation:
1. Addition
2. Subtraction
3. Multiplication
4. Transpose (A)
5. Determinant (A)
""")

choice = int(input("Enter choice (1-5): "))

if choice == 1:
    print("Result:\n", A + B)

elif choice == 2:
    print("Result:\n", A - B)

elif choice == 3:
    print("Result:\n", np.dot(A, B))

elif choice == 4:
    print("Transpose of A:\n", A.T)

elif choice == 5:
    if A.shape[0] == A.shape[1]:
        print("Determinant of A:", np.linalg.det(A))
    else:
        print("Determinant not possible (A square nahi hai)")

else:
    print("Invalid choice")
